import modern
#print(dir(modern))

modern.order_food("Salad", "Pizza", "Biryani", "Soup")
modern.vac_feedback(efficacy=34, vac="Unknown")
modern.time_activity(10, 20, 10, hobby="Dance", sport="Boxing", fun="Driving", work="DevOps")