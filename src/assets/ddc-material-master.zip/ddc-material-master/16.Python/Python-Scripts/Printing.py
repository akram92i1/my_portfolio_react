name="sars_cov_2"
disease="covid19"

print("The name os virus is ", name)
print("The name of virus is {}".format(name))

print("{} is the name of virus.".format(name))

print("The name of virus is {} and it causes {}".format(name, disease))

print(f"The name of virus is {name} and it causes {disease}")

# Concatenation
print("The name of virus is" + " " + name)
