#!/bin/bash


for VAR1 in java .net python ruby php
do
  echo "Looping....."
  echo "###################################################"
  echo "Value of VAR1 is $VAR1."
  echo "###################################################"
  pwd
done

echo "Out of for loop"
date
